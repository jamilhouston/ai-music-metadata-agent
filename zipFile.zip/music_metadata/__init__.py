"""Music metadata agent package."""

